public class Artefact extends Entity {
    public Artefact(){
        this.setProperty("artefact");
    }
}
