public class Furniture extends Entity {
    public Furniture(){
        this.setProperty("furniture");
    }
}
