drop table if exists Post_Like;
drop table if exists Topic_Like;

CREATE TABLE Post_Like(
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    personId INTEGER NOT NULL ,
    postId INTEGER NOT NULL ,
    CONSTRAINT post_PostLike foreign key (postId) references Post(id),
    CONSTRAINT person_PostLike foreign key (personId) references Person(id)
);

CREATE TABLE Topic_Like(
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    personId INTEGER NOT NULL ,
    topicId INTEGER NOT NULL ,
    CONSTRAINT topic_TopicLike foreign key (topicId) references Topic(id),
    CONSTRAINT person_TopicLike foreign key (personId) references Person(id)
);