drop database if exists bb;
create database bb;
use bb;

drop table if exists Post;
drop table if exists Topic;
drop table if exists Forum;
drop table if exists Person;

CREATE TABLE Person (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    username VARCHAR(10) NOT NULL UNIQUE,
    stuId VARCHAR(10) NULL
);

CREATE TABLE Forum(
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE Topic(
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    forumId INTEGER NOT NULL ,
    personId INTEGER NOT NULL ,
    title VARCHAR(255) NOT NULL,
    CONSTRAINT forum_Topic foreign key (forumId) references Forum(id),
    CONSTRAINT person_Topic foreign key (personId) references Person(id)
);

CREATE TABLE Post(
     id INTEGER PRIMARY KEY AUTO_INCREMENT,
     topicId INTEGER NOT NULL ,
     personId INTEGER NOT NULL ,
     text VARCHAR(255) NOT NULL ,
     time VARCHAR(100) NOT NULL ,
     CONSTRAINT topic_Post foreign key (topicId) references Topic(id),
     CONSTRAINT person_Post foreign key (personId) references Person(id)
);